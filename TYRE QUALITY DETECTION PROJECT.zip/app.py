from keras.models import load_model
from flask import Flask,request,jsonify,render_template
import numpy as np
import pandas as pd
import re
import pickle
from skimage.transform import resize
from keras.preprocessing import image
from werkzeug.utils import secure_filename
from scipy.misc import imsave, imread, imresize

app=Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')
@app.route('/y_predict',methods=['POST'])
def y_predict():
    """
        For rendering results on HTML GUI
    """
    
    frame=imread(request.files['img'])
    model=load_model('mymodel.h5')
    img=resize(frame,(64,64))
    img=np.expand_dims(img,axis=0)
    if(np.max(img)>1):
        img=img/255.0
    prediction=model.predict_classes(img)
    if(prediction==1):
        return render_template('index.html',prediction_text='It is a tyre with good condition')
    else:
        return render_template('index.html',prediction_text='It is a Bad Tyre')
    

if(__name__=='__main__'):
    app.run(debug=True)
